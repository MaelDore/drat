library(testthat)
library(BioGeoBEARS)
test_dir(path="testthat")
